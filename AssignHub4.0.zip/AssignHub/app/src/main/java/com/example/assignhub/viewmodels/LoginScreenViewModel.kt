package com.example.assignhub.viewmodels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

enum class AuthMode {
    LOGIN, REGISTER, RESET
}

class LoginScreenViewModel : ViewModel() {
    var authMode by mutableStateOf(AuthMode.LOGIN)
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmPassword by mutableStateOf("")
    var isLoading by mutableStateOf(false)

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().reference

    // Predefined Employee/Manager Data
    private val authorizedUsers = mapOf(
        "rohanhtandale11@gmail.com" to "Rohan Tandale",
        "mdfaizjamal611@gmail.com" to "Md Faiz Jamal",
        "kishansingam4@gmail.com" to "Kishan Singam",
        "skayan2910@gmail.com" to "Ayan Sheikh",
        "hardikbaraskar262@gmail.com" to "Hardik Baraskar"
    )

    private val managerEmails = listOf("mdfaizjamal611@gmail.com")
    private val employeeEmails = listOf("kishansingam4@gmail.com", "skayan2910@gmail.com", "rohanhtandale11@gmail.com","hardikbaraskar262@gmail.com")

    // Validation Logic
    val isPasswordMatch get() = password.trim() == confirmPassword.trim()
    val isEmailAuthorized get() = email.trim() in managerEmails || email.trim() in employeeEmails

    // Password Validation Logic
    private fun isPasswordValid(pass: String): Boolean {
        val trimmedPass = pass.trim()
        if (trimmedPass.length < 5) return false
        val hasUpperCase = trimmedPass.any { it.isUpperCase() }
        val hasLowerCase = trimmedPass.any { it.isLowerCase() }
        val hasDigit = trimmedPass.any { it.isDigit() }
        val hasSpecialChar = trimmedPass.any { !it.isLetterOrDigit() }
        return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar
    }

    // Logic for button action
    val canSubmit get() = when (authMode) {
        AuthMode.LOGIN -> email.isNotEmpty() && password.isNotEmpty()
        AuthMode.REGISTER -> email.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty()
        AuthMode.RESET -> email.isNotEmpty()
    }

    fun resetState() {
        email = ""
        password = ""
        confirmPassword = ""
        isLoading = false
        authMode = AuthMode.LOGIN
    }

    fun handleAuth(
        onNavigateToManager: () -> Unit,
        onNavigateToEmployee: () -> Unit,
        onShowToast: (String) -> Unit
    ) {
        val trimmedEmail = email.trim()
        val trimmedPassword = password.trim()
        val trimmedConfirmPassword = confirmPassword.trim()

        if (trimmedEmail.isEmpty()) {
            onShowToast("Please enter your email")
            return
        }

        if (authMode != AuthMode.RESET && trimmedPassword.isEmpty()) {
            onShowToast("Please enter your password")
            return
        }

        if (authMode == AuthMode.REGISTER) {
            // Check for any spaces within the password (even after trimming ends)
            if (trimmedPassword.contains(" ")) {
                onShowToast("Password cannot contain spaces")
                return
            }

            if (!isPasswordValid(trimmedPassword)) {
                onShowToast("Weak Password! Use min 5 chars with A, a, 1, @ (e.g. Kk@123)")
                return
            }
            if (trimmedConfirmPassword.isEmpty()) {
                onShowToast("Please confirm your password")
                return
            }
            if (trimmedPassword != trimmedConfirmPassword) {
                onShowToast("Passwords do not match")
                return
            }
            if (!isEmailAuthorized) {
                onShowToast("Registration Failed: Email not authorized")
                return
            }
        }

        isLoading = true
        when (authMode) {
            AuthMode.LOGIN -> {
                auth.signInWithEmailAndPassword(trimmedEmail, trimmedPassword)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val userId = auth.currentUser?.uid ?: ""
                            if (isEmailAuthorized) {
                                database.child("users").child(userId).child("password").setValue(trimmedPassword)
                                    .addOnCompleteListener {
                                        onShowToast("Login Successful")
                                        if (trimmedEmail in managerEmails) onNavigateToManager()
                                        else onNavigateToEmployee()
                                    }
                            } else {
                                onShowToast("Unauthorized access: Email not registered")
                                auth.signOut()
                                isLoading = false
                            }
                        } else {
                            onShowToast("Login Failed: Incorrect email or password")
                            isLoading = false
                        }
                    }
            }
            AuthMode.REGISTER -> {
                auth.createUserWithEmailAndPassword(trimmedEmail, trimmedPassword)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val userId = auth.currentUser?.uid ?: ""
                            val role = if (trimmedEmail in managerEmails) "manager" else "employee"
                            val userName = authorizedUsers[trimmedEmail] ?: "User"

                            val userData = mapOf(
                                "name" to userName,
                                "email" to trimmedEmail,
                                "role" to role,
                                "isPasswordGenerated" to true,
                                "password" to trimmedPassword
                            )
                            database.child("users").child(userId).setValue(userData)
                                .addOnSuccessListener {
                                    onShowToast("Account Created for $userName. Please Login.")
                                    auth.signOut()
                                    authMode = AuthMode.LOGIN
                                    password = ""
                                    confirmPassword = ""
                                }
                        } else {
                            onShowToast("Registration Failed: ${task.exception?.message}")
                        }
                        isLoading = false
                    }
            }
            AuthMode.RESET -> {
                auth.sendPasswordResetEmail(trimmedEmail)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            onShowToast("Reset link sent to your email")
                            authMode = AuthMode.LOGIN
                        } else {
                            onShowToast("Error: ${task.exception?.message}")
                        }
                        isLoading = false
                    }
            }
        }
    }
}
