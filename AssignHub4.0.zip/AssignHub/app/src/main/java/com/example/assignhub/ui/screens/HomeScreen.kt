package com.example.assignhub.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assignhub.R

@Composable
fun HomeScreen(onNavigateToLogin: () -> Unit) {
    // Colors extracted from the logo
    val logoBlue = Color(0xFF004A8D)
    val logoOrange = Color(0xFFF37021)
    val bgLight = Color(0xFFF8FAFC)

    // Entry Animation state
    var startAnimation by remember { mutableStateOf(false) }
    
    val scale by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.7f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale"
    )
    
    val alpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1000),
        label = "alpha"
    )

    // Smooth Slide from Top Animation with a slight bounce
    val offsetY by animateDpAsState(
        targetValue = if (startAnimation) 0.dp else (-150).dp,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "offsetY"
    )

    // Shine effect animation
    val infiniteTransition = rememberInfiniteTransition(label = "shine")
    val shineOffset by infiniteTransition.animateFloat(
        initialValue = -500f,
        targetValue = 1500f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, delayMillis = 500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shineOffset"
    )

    LaunchedEffect(Unit) {
        startAnimation = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(bgLight, Color(0xFFE2E8F0)))),
        contentAlignment = Alignment.Center
    ) {
        // Subtle Background Decorative Elements (Fillers)
        Box(
            modifier = Modifier
                .size(450.dp)
                .offset(x = (-180).dp, y = (-300).dp)
                .alpha(0.06f) // Slightly more visible as requested
                .background(logoBlue, CircleShape)
        )
        Box(
            modifier = Modifier
                .size(300.dp)
                .offset(x = 200.dp, y = 400.dp)
                .alpha(0.06f)
                .background(logoOrange, CircleShape)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated Logo Section - Smooth Slide from top
            Box(
                modifier = Modifier
                    .offset(y = offsetY)
                    .scale(scale)
                    .alpha(alpha)
                    .fillMaxWidth()
                    .height(300.dp),
                contentAlignment = Alignment.Center
            ) {
                // THE LOGO IMAGE
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "AssignHub Branding",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
                
                // Shine Overlay
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.35f),
                                    Color.Transparent
                                ),
                                start = androidx.compose.ui.geometry.Offset(shineOffset, shineOffset),
                                end = androidx.compose.ui.geometry.Offset(shineOffset + 250f, shineOffset + 250f)
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(60.dp))

            // Action Button with Arrow Icon and Black Text for visibility
            Button(
                onClick = onNavigateToLogin,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .alpha(alpha)
                    .scale(if (startAnimation) 1f else 0.9f),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = logoOrange,
                    contentColor = Color.Black // Changed to Black for visibility
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 8.dp,
                    pressedElevation = 2.dp
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "GO TO LOGIN PAGE",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = Color.Black // Explicitly set to Black
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        tint = Color.Black // Icon also in Black
                    )
                }
            }
        }
    }
}
