package com.example.assignhub.models

data class Employee(
    val email: String,
    val initials: String,
    val name: String
)
