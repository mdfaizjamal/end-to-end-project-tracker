package com.example.assignhub.utils

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

/**
 * Utility to highlight specific text within a string for search results.
 * Shared across dashboards.
 */
fun getHighlightedText(text: String, query: String, accentColor: Color): AnnotatedString {
    if (query.isEmpty() || !text.contains(query, ignoreCase = true)) {
        return AnnotatedString(text)
    }

    return buildAnnotatedString {
        var start = 0
        while (start < text.length) {
            val index = text.indexOf(query, start, ignoreCase = true)
            if (index == -1) {
                append(text.substring(start))
                break
            }
            append(text.substring(start, index))
            withStyle(SpanStyle(background = accentColor.copy(alpha = 0.2f), fontWeight = FontWeight.ExtraBold, color = Color.Black)) {
                append(text.substring(index, index + query.length))
            }
            start = index + query.length
        }
    }
}
