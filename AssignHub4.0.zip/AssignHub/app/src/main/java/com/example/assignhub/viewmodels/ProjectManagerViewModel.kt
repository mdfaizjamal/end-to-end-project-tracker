package com.example.assignhub.viewmodels

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.assignhub.models.AppNotification
import com.example.assignhub.models.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.UUID

class ProjectManagerViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().getReference("AssignTask")
    private val usersDatabase = FirebaseDatabase.getInstance().getReference("users")
    private val notificationsDatabase = FirebaseDatabase.getInstance().getReference("manager_notifications")
    private val employeeNotificationsDatabase = FirebaseDatabase.getInstance().getReference("employee_notifications")

    private val _tasks = mutableStateOf<List<Task>>(emptyList())
    val tasks: State<List<Task>> = _tasks

    private val _isLoading = mutableStateOf(false)
    val isLoading: State<Boolean> = _isLoading

    private val _managerName = mutableStateOf("Admin")
    val managerName: State<String> = _managerName

    private val _notifications = mutableStateOf<List<AppNotification>>(emptyList())
    val notifications: State<List<AppNotification>> = _notifications

    init {
        fetchManagerName()
        fetchTasks()
        fetchNotifications()
    }

    private fun fetchManagerName() {
        val userId = auth.currentUser?.uid ?: return
        usersDatabase.child(userId).child("name").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val name = snapshot.getValue(String::class.java)
                if (!name.isNullOrEmpty()) {
                    _managerName.value = name
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun fetchTasks() {
        _isLoading.value = true
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val taskList = mutableListOf<Task>()
                for (taskSnapshot in snapshot.children) {
                    val task = taskSnapshot.getValue(Task::class.java)
                    val isDeleted = taskSnapshot.child("isDeletedByManager").getValue(Boolean::class.java) ?: false ||
                                   taskSnapshot.child("deletedbymanager").getValue(Boolean::class.java) ?: false
                    
                    if (task != null && !isDeleted) {
                        taskList.add(task)
                    }
                }
                _tasks.value = taskList.sortedByDescending { it.createdAt }
                _isLoading.value = false
            }

            override fun onCancelled(error: DatabaseError) {
                _isLoading.value = false
            }
        })
    }

    private fun fetchNotifications() {
        notificationsDatabase.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val notifList = mutableListOf<AppNotification>()
                for (notifSnapshot in snapshot.children) {
                    val notif = notifSnapshot.getValue(AppNotification::class.java)
                    if (notif != null) {
                        notifList.add(notif)
                    }
                }
                _notifications.value = notifList.sortedByDescending { it.timestamp }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun addTask(
        title: String,
        description: String,
        assignedTo: List<String>, // Emails list
        assignedToNames: List<String>,
        priority: String,
        deadline: String,
        deadlineTime: String
    ) {
        val taskId = database.push().key ?: UUID.randomUUID().toString()
        val newTask = Task(
            id = taskId,
            title = title,
            description = description,
            assignedTo = assignedTo,
            assignedToNames = assignedToNames,
            priority = priority,
            deadline = deadline,
            deadlineTime = deadlineTime,
            status = "PENDING",
            createdAt = System.currentTimeMillis()
        )
        database.child(taskId).setValue(newTask).addOnSuccessListener {
            // Send unique notification to each assigned employee
            assignedTo.forEachIndexed { index, email ->
                val notification = AppNotification(
                    id = UUID.randomUUID().toString(),
                    title = "New Task Assigned",
                    message = "${_managerName.value} assigned \"$title\". Deadline: $deadline $deadlineTime",
                    timestamp = System.currentTimeMillis(),
                    type = "TASK_ASSIGNED",
                    targetEmployeeName = assignedToNames.getOrNull(index) ?: "",
                    targetEmployeeEmail = email
                )
                employeeNotificationsDatabase.push().setValue(notification)
            }
        }
    }

    fun updateTaskStatus(taskId: String, status: String, rejectionReason: String = "") {
        val task = _tasks.value.find { it.id == taskId } ?: return
        
        val updates = mutableMapOf<String, Any>(
            "status" to status
        )
        
        if (status == "REJECTED") {
            updates["submissionStatus"] = "NOT_SUBMITTED"
            if (rejectionReason.isNotEmpty()) {
                updates["rejectionReason"] = rejectionReason
            }
        } else if (status == "APPROVED") {
            updates["rejectionReason"] = ""
        }
        
        database.child(taskId).updateChildren(updates).addOnSuccessListener {
            val notificationTitle = if (status == "APPROVED") "Task Approved" else "Task Rejected"
            val notificationMessage = if (status == "APPROVED") {
                "Your submission for \"${task.title}\" has been approved."
            } else {
                "Your submission for \"${task.title}\" was rejected. Reason: $rejectionReason"
            }
            
            // Notify all assigned employees about the status change
            task.assignedTo.forEachIndexed { index, email ->
                val notification = AppNotification(
                    id = UUID.randomUUID().toString(),
                    title = notificationTitle,
                    message = notificationMessage,
                    timestamp = System.currentTimeMillis(),
                    type = "TASK_STATUS_UPDATE",
                    targetEmployeeName = task.assignedToNames.getOrNull(index) ?: "",
                    targetEmployeeEmail = email
                )
                employeeNotificationsDatabase.push().setValue(notification)
            }
        }
    }

    fun deleteTask(taskId: String) {
        val updates = mapOf(
            "isDeletedByManager" to true,
            "deletedbymanager" to true
        )
        database.child(taskId).updateChildren(updates)
    }

    fun clearNotifications() {
        notificationsDatabase.removeValue()
    }

    fun logout(onLogout: () -> Unit) {
        auth.signOut()
        onLogout()
    }
}
