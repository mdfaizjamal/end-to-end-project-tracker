package com.example.assignhub

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.*
import com.example.assignhub.services.DeadlineWorker
import com.example.assignhub.ui.screens.EmployeeScreen
import com.example.assignhub.ui.screens.HomeScreen
import com.example.assignhub.ui.screens.LoginScreen
import com.example.assignhub.ui.screens.ProjectManagerScreen
import com.example.assignhub.ui.theme.AssignHubTheme
import com.example.assignhub.viewmodels.LoginScreenViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Toast.makeText(this, "Notifications enabled", Toast.LENGTH_SHORT).show()
            getAndStoreFcmToken()
        } else {
            Toast.makeText(this, "Notifications permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        askNotificationPermission()
        getAndStoreFcmToken()
        scheduleDeadlineWorker()

        setContent {
            AssignHubTheme {
                val loginViewModel: LoginScreenViewModel = viewModel()
                var currentScreen by rememberSaveable { mutableStateOf("loading") }
                
                // Check if user is already logged in
                LaunchedEffect(Unit) {
                    val currentUser = FirebaseAuth.getInstance().currentUser
                    if (currentUser != null) {
                        // Fetch role from DB
                        FirebaseDatabase.getInstance().getReference("users")
                            .child(currentUser.uid)
                            .child("role")
                            .get()
                            .addOnSuccessListener { snapshot ->
                                val role = snapshot.getValue(String::class.java)
                                currentScreen = if (role == "manager") "manager" else "employee"
                            }
                            .addOnFailureListener {
                                currentScreen = "home"
                            }
                    } else {
                        currentScreen = "home"
                    }
                }

                BackHandler(enabled = true) {
                    when (currentScreen) {
                        "home" -> finish()
                        "login" -> currentScreen = "home"
                        "manager", "employee" -> finish()
                        else -> finish()
                    }
                }

                Surface(modifier = Modifier.fillMaxSize()) {
                    when (currentScreen) {
                        "loading" -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Color(0xFF004A8D))
                            }
                        }
                        "home" -> HomeScreen(onNavigateToLogin = { currentScreen = "login" })
                        "login" -> LoginScreen(
                            onBack = { currentScreen = "home" },
                            onNavigateToManager = { 
                                currentScreen = "manager"
                                getAndStoreFcmToken()
                            },
                            onNavigateToEmployee = { 
                                currentScreen = "employee"
                                getAndStoreFcmToken()
                            },
                            viewModel = loginViewModel
                        )
                        "manager" -> ProjectManagerScreen(onLogout = { 
                            FirebaseAuth.getInstance().signOut()
                            loginViewModel.resetState()
                            currentScreen = "login"
                            Toast.makeText(this, "Successfully logged out", Toast.LENGTH_SHORT).show()
                        })
                        "employee" -> EmployeeScreen(onLogout = { 
                            FirebaseAuth.getInstance().signOut()
                            loginViewModel.resetState()
                            currentScreen = "login"
                            Toast.makeText(this, "Successfully logged out", Toast.LENGTH_SHORT).show()
                        })
                    }
                }
            }
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun getAndStoreFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w("FCM", "Fetching FCM registration token failed", task.exception)
                return@addOnCompleteListener
            }
            val token = task.result
            val userId = FirebaseAuth.getInstance().currentUser?.uid
            if (userId != null && token != null) {
                FirebaseDatabase.getInstance().getReference("users")
                    .child(userId)
                    .child("fcmToken")
                    .setValue(token)
            }
        }
    }

    private fun scheduleDeadlineWorker() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val periodicWorkRequest = PeriodicWorkRequestBuilder<DeadlineWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "DeadlineWorkerPeriodic",
            ExistingPeriodicWorkPolicy.KEEP,
            periodicWorkRequest
        )

        val immediateWorkRequest = OneTimeWorkRequestBuilder<DeadlineWorker>()
            .setConstraints(constraints)
            .build()
        
        WorkManager.getInstance(this).enqueue(immediateWorkRequest)
    }
}
