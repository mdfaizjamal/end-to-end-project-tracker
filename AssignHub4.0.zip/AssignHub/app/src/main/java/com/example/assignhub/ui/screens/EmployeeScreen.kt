package com.example.assignhub.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.assignhub.models.Task
import com.example.assignhub.utils.getHighlightedText
import com.example.assignhub.viewmodels.EmployeeViewModel
import java.util.*

@Composable
fun EmployeeScreen(
    onLogout: () -> Unit,
    viewModel: EmployeeViewModel = viewModel()
) {
    val tasks by viewModel.tasks
    val isLoading by viewModel.isLoading
    val employeeName by viewModel.employeeName
    val notifications by viewModel.notifications
    val overdueTask by viewModel.overdueTaskToNotify
    
    var searchQuery by remember { mutableStateOf("") }
    var isSearchVisible by remember { mutableStateOf(false) }
    var showNotifications by remember { mutableStateOf(false) }
    var selectedTaskForDetail by remember { mutableStateOf<Task?>(null) }
    
    // Confirmation Dialog State
    var showSubmitConfirmation by remember { mutableStateOf(false) }
    var taskIdToSubmit by remember { mutableStateOf<String?>(null) }
    
    // Filter State
    var selectedFilter by remember { mutableStateOf("ALL") }
    var showFilterMenu by remember { mutableStateOf(false) }
    
    val empAccent = Color(0xFF004A8D) // Logo Blue Theme
    val empBg = Color(0xFFF1F5F9)

    // REFRESH DATA ONCE WHEN SCREEN OPENS
    LaunchedEffect(Unit) {
        viewModel.refreshData()
    }

    // HANDLE BACK BUTTON WITHIN SCREEN
    BackHandler(enabled = showNotifications || selectedTaskForDetail != null || isSearchVisible) {
        if (showNotifications) {
            showNotifications = false
        } else if (selectedTaskForDetail != null) {
            selectedTaskForDetail = null
        } else if (isSearchVisible) {
            isSearchVisible = false
            searchQuery = ""
        }
    }

    // Overdue Notification Popup
    if (overdueTask != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissOverdueNotification() },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red) },
            title = { Text("Deadline Missed!", color = Color.Red, fontWeight = FontWeight.Bold) },
            text = { 
                Column {
                    Text("Your project \"${overdueTask?.title}\" deadline is over.")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Deadline was: ${overdueTask?.deadline} ${overdueTask?.deadlineTime}", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("You are not able to complete the task. Please communicate with your manager.", fontWeight = FontWeight.Medium)
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissOverdueNotification() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("I Understand")
                }
            }
        )
    }

    // Submission Confirmation Dialog
    if (showSubmitConfirmation && taskIdToSubmit != null) {
        AlertDialog(
            onDismissRequest = { 
                showSubmitConfirmation = false
                taskIdToSubmit = null
            },
            title = { Text("Confirm Submission") },
            text = { Text("Are you sure you want to submit your work for this task?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitWork(taskIdToSubmit!!)
                        showSubmitConfirmation = false
                        taskIdToSubmit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = empAccent)
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { 
                    showSubmitConfirmation = false
                    taskIdToSubmit = null
                }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    val filteredTasks = tasks.filter { task ->
        val matchesSearch = if (searchQuery.isEmpty()) true else {
            task.title.contains(searchQuery, ignoreCase = true) || 
            task.description.contains(searchQuery, ignoreCase = true)
        }
        val matchesFilter = if (selectedFilter == "ALL") true else task.status == selectedFilter
        matchesSearch && matchesFilter
    }

    if (showNotifications) {
        NotificationsScreen(
            notifications = notifications,
            onClearAll = { viewModel.clearNotifications() },
            onBack = { showNotifications = false }
        )
    } else if (selectedTaskForDetail != null) {
        EmployeeTaskDetailScreen(
            task = selectedTaskForDetail!!,
            accentColor = empAccent,
            onBack = { selectedTaskForDetail = null }
        )
    } else {
        Scaffold(
            modifier = Modifier.statusBarsPadding()
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(empBg)
                    .padding(padding)
            ) {
                // Employee Header with Logout, Search and Filter Toggles
                EmployeeHeaderSection(
                    employeeName = employeeName.ifEmpty { "Employee" },
                    accentColor = empAccent,
                    onLogout = { viewModel.logout(onLogout) },
                    onSearchToggle = { isSearchVisible = !isSearchVisible },
                    onFilterToggle = { showFilterMenu = true },
                    onNotificationsClick = { showNotifications = true },
                    notificationCount = notifications.size
                )

                // Filter Menu (Top Right)
                Box(modifier = Modifier.fillMaxWidth().wrapContentSize(Alignment.TopEnd).padding(end = 24.dp)) {
                    DropdownMenu(
                        expanded = showFilterMenu,
                        onDismissRequest = { showFilterMenu = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        listOf("ALL", "PENDING", "APPROVED", "REJECTED").forEach { filter ->
                            DropdownMenuItem(
                                text = { 
                                    Text(
                                        text = filter, 
                                        fontWeight = if (selectedFilter == filter) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedFilter == filter) empAccent else Color.Black
                                    ) 
                                },
                                onClick = {
                                    selectedFilter = filter
                                    showFilterMenu = false
                                }
                            )
                        }
                    }
                }

                // Search Bar
                AnimatedVisibility(
                    visible = isSearchVisible,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        placeholder = { Text("Search your tasks...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = empAccent) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search", tint = Color.Gray)
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = empAccent,
                            unfocusedBorderColor = Color.LightGray,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Color.Black,
                            unfocusedTextColor = Color.Black
                        ),
                        singleLine = true
                    )
                }

                if (isLoading && tasks.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = empAccent)
                    }
                } else if (tasks.isEmpty() && searchQuery.isEmpty() && selectedFilter == "ALL") {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No tasks assigned to you yet.", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (searchQuery.isEmpty() && selectedFilter == "ALL") "MY ASSIGNED TASKS" else "FILTERED TASKS",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                                
                                if (selectedFilter != "ALL") {
                                    Surface(
                                        modifier = Modifier.clickable { selectedFilter = "ALL" },
                                        shape = RoundedCornerShape(16.dp),
                                        color = empAccent.copy(alpha = 0.1f),
                                        border = BorderStroke(1.dp, empAccent.copy(alpha = 0.5f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(selectedFilter, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = empAccent)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp), tint = empAccent)
                                        }
                                    }
                                }
                            }
                        }

                        items(tasks.filter { task ->
                            val matchesSearch = if (searchQuery.isEmpty()) true else {
                                task.title.contains(searchQuery, ignoreCase = true) || 
                                task.description.contains(searchQuery, ignoreCase = true)
                            }
                            val matchesFilter = if (selectedFilter == "ALL") true else task.status == selectedFilter
                            matchesSearch && matchesFilter
                        }) { task ->
                            EmployeeTaskCard(
                                task = task,
                                accentColor = empAccent,
                                searchQuery = searchQuery,
                                onClick = { selectedTaskForDetail = task },
                                onSubmit = { 
                                    taskIdToSubmit = task.id
                                    showSubmitConfirmation = true 
                                },
                                onDelete = { viewModel.deleteTask(task.id) }
                            )
                        }
                        
                        if (filteredTasks.isEmpty() && !isLoading) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                                    Text("No tasks found matching criteria.", color = Color.Gray)
                                }
                            }
                        }
                        
                        item { Spacer(modifier = Modifier.height(30.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun EmployeeHeaderSection(
    employeeName: String, 
    accentColor: Color, 
    onLogout: () -> Unit, 
    onSearchToggle: () -> Unit,
    onFilterToggle: () -> Unit,
    onNotificationsClick: () -> Unit,
    notificationCount: Int = 0
) {
    val calendar = Calendar.getInstance()
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val greeting = when (hour) {
        in 0..11 -> "Good Morning"
        in 12..16 -> "Good Afternoon"
        else -> "Good Evening"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
                modifier = Modifier.size(45.dp).background(accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val initials = if (employeeName.contains(" ")) {
                    employeeName.take(1) + employeeName.split(" ").last().take(1)
                } else if (employeeName.isNotEmpty()) {
                    employeeName.take(2).uppercase()
                } else {
                    "EM"
                }
                Text(initials, color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "Hi, $employeeName", 
                    fontWeight = FontWeight.Black, 
                    fontSize = 20.sp, 
                    letterSpacing = (-0.5).sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text("$greeting, Here are your tasks", color = accentColor, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onSearchToggle) {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray)
            }
            IconButton(onClick = onFilterToggle) {
                Icon(Icons.Default.FilterList, contentDescription = "Filter", tint = Color.Gray)
            }
            IconButton(onClick = onNotificationsClick) {
                if (notificationCount > 0) {
                    BadgedBox(badge = { Badge { Text(notificationCount.toString()) } }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = accentColor)
                    }
                } else {
                    Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = onLogout) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = Color.Red)
            }
        }
    }
}

@Composable
fun EmployeeTaskCard(
    task: Task,
    accentColor: Color,
    searchQuery: String,
    onClick: () -> Unit,
    onSubmit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = accentColor.copy(alpha = 0.4f),
                spotColor = accentColor
            )
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
    ) {
        Box {
            // Priority Indicator Strip (Left)
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(6.dp)
                    .background(
                        when (task.priority) {
                            "HIGH" -> Color(0xFFE53935)
                            "MEDIUM" -> Color(0xFFFB8C00)
                            else -> Color(0xFF43A047)
                        }
                    )
                    .align(Alignment.CenterStart)
            )

            Column(modifier = Modifier.padding(start = 22.dp, end = 20.dp, top = 20.dp, bottom = 20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = getHighlightedText(task.title, searchQuery, accentColor),
                        fontWeight = FontWeight.ExtraBold, 
                        fontSize = 18.sp, 
                        color = Color(0xFF1E293B),
                        modifier = Modifier.weight(1f)
                    )
                    
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (task.status == "APPROVED") {
                            IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
                            }
                        }

                        // Priority Badge
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when (task.priority) {
                                "HIGH" -> Color(0xFFFFEBEE)
                                "MEDIUM" -> Color(0xFFFFF3E0)
                                else -> Color(0xFFE8F5E9)
                            },
                            border = BorderStroke(1.dp, when (task.priority) {
                                "HIGH" -> Color(0xFFEF9A9A)
                                "MEDIUM" -> Color(0xFFFFCC80)
                                else -> Color(0xFFA5D6A7)
                            })
                        ) {
                            Text(
                                task.priority, 
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = when (task.priority) {
                                    "HIGH" -> Color(0xFFC62828)
                                    "MEDIUM" -> Color(0xFFEF6C00)
                                    else -> Color(0xFF2E7D32)
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = getHighlightedText(task.description, searchQuery, accentColor),
                    color = Color.Black, 
                    fontSize = 14.sp, 
                    maxLines = 2,
                    lineHeight = 18.sp
                )
                
                Spacer(modifier = Modifier.height(18.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth, 
                            contentDescription = null, 
                            modifier = Modifier.size(14.dp), 
                            tint = accentColor
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            val isOverdue = try {
                                val sdf = java.text.SimpleDateFormat("dd MMM yyyy hh:mm a", Locale.getDefault())
                                val deadline = sdf.parse("${task.deadline} ${task.deadlineTime}")?.time ?: Long.MAX_VALUE
                                deadline < System.currentTimeMillis() && task.submissionStatus != "SUBMITTED"
                            } catch (e: Exception) { false }

                            Text(
                                text = task.deadline, 
                                fontSize = 12.sp, 
                                color = if (isOverdue) Color.Red else Color(0xFF475569), 
                                fontWeight = FontWeight.Bold
                            )
                            if (task.deadlineTime.isNotEmpty()) {
                                Text(
                                    text = task.deadlineTime, 
                                    fontSize = 10.sp, 
                                    color = if (isOverdue) Color.Red.copy(alpha = 0.7f) else Color.Gray, 
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Submission Badge
                        Surface(
                            shape = CircleShape,
                            color = if (task.submissionStatus == "SUBMITTED") accentColor.copy(alpha = 0.1f) else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (task.submissionStatus == "SUBMITTED") accentColor.copy(alpha = 0.2f) else Color.Transparent)
                        ) {
                            Text(
                                text = if (task.submissionStatus == "SUBMITTED") "SUBMITTED" else "NOT SUBMITTED",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = if (task.submissionStatus == "SUBMITTED") accentColor else Color.Gray
                            )
                        }

                        if (task.submissionStatus != "SUBMITTED") {
                            Button(
                                onClick = { onSubmit() },
                                modifier = Modifier.height(38.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Submit", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        } else if (task.status == "APPROVED") {
                            Icon(
                                imageVector = Icons.Default.CheckCircle, 
                                contentDescription = "Approved", 
                                tint = Color(0xFF2E7D32), 
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
                
                // Show Rejection Reason if applicable
                if (task.status == "REJECTED") {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFFFFEBEE).copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("REJECTION REASON", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color(0xFFC62828))
                            Text(task.rejectionReason, fontSize = 12.sp, color = Color.Black.copy(alpha = 0.7f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmployeeTaskDetailScreen(task: Task, accentColor: Color, onBack: () -> Unit) {
    val bgColor = Color(0xFFF1F5F9)

    Surface(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        color = bgColor
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .size(40.dp)
                        .clickable { onBack() },
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 2.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack, 
                            contentDescription = "Back", 
                            modifier = Modifier.size(20.dp),
                            tint = Color.Black
                        )
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("Task Overview", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .shadow(10.dp, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = task.title,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1E293B)
                        )
                        Badge(
                            containerColor = when (task.priority) {
                                "HIGH" -> Color(0xFFFFEBEE)
                                "MEDIUM" -> Color(0xFFFFF3E0)
                                else -> Color(0xFFE8F5E9)
                            },
                            contentColor = when (task.priority) {
                                "HIGH" -> Color(0xFFD32F2F)
                                "MEDIUM" -> Color(0xFFEF6C00)
                                else -> Color(0xFF2E7D32)
                            }
                        ) {
                            Text(task.priority, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "MANAGER STATUS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text(
                                text = task.status,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = when(task.status) {
                                    "APPROVED" -> Color(0xFF2E7D32)
                                    "REJECTED" -> Color(0xFFC62828)
                                    else -> accentColor
                                }
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SUBMISSION",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text(
                                text = if (task.submissionStatus == "SUBMITTED") "SUBMITTED" else "NOT SUBMITTED",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (task.submissionStatus == "SUBMITTED") accentColor else Color.Gray
                            )
                        }
                    }

                    if (task.status == "REJECTED") {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "REJECTION REASON",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Red
                        )
                        Text(task.rejectionReason, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "DESCRIPTION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Text(
                        text = task.description,
                        fontSize = 15.sp,
                        color = Color.Black,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "DEADLINE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp), tint = accentColor)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${task.deadline} ${task.deadlineTime}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TEAM",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                task.assignedToNames.forEach { name ->
                                    Text(name, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
