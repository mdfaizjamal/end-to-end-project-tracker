package com.example.assignhub.models

data class SubmittedTask(
    val taskId: String = "",
    val taskTitle: String = "",
    val employeeName: String = "",
    val submissionDate: String = "",
    val submissionTime: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
