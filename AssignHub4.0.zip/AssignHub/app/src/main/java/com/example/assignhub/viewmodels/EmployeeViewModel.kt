package com.example.assignhub.viewmodels

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.assignhub.models.AppNotification
import com.example.assignhub.models.SubmittedTask
import com.example.assignhub.models.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class EmployeeViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().reference
    private val managerNotificationsDatabase = FirebaseDatabase.getInstance().getReference("manager_notifications")
    private val employeeNotificationsDatabase = FirebaseDatabase.getInstance().getReference("employee_notifications")
    
    private val _tasks = mutableStateOf<List<Task>>(emptyList())
    val tasks: State<List<Task>> = _tasks

    private val _isLoading = mutableStateOf(false)
    val isLoading: State<Boolean> = _isLoading

    private val _employeeName = mutableStateOf("")
    val employeeName: State<String> = _employeeName
    
    private val _employeeEmail = mutableStateOf("")

    private val _notifications = mutableStateOf<List<AppNotification>>(emptyList())
    val notifications: State<List<AppNotification>> = _notifications

    private val _overdueTaskToNotify = mutableStateOf<Task?>(null)
    val overdueTaskToNotify: State<Task?> = _overdueTaskToNotify

    init {
        refreshData()
    }

    fun refreshData() {
        val userId = auth.currentUser?.uid ?: return
        _isLoading.value = true
        _tasks.value = emptyList()
        _notifications.value = emptyList()
        _employeeName.value = ""
        _employeeEmail.value = ""
        
        fetchEmployeeData()
    }

    private fun fetchEmployeeData() {
        val userId = auth.currentUser?.uid ?: return

        database.child("users").child(userId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val name = snapshot.child("name").getValue(String::class.java) ?: ""
                val email = snapshot.child("email").getValue(String::class.java) ?: ""
                _employeeName.value = name
                _employeeEmail.value = email
                
                if (email.isNotEmpty()) {
                    fetchTasksForEmployee(email)
                    fetchNotificationsForEmployee(email)
                } else {
                    _isLoading.value = false
                }
            }

            override fun onCancelled(error: DatabaseError) {
                _isLoading.value = false
            }
        })
    }

    private fun fetchTasksForEmployee(email: String) {
        database.child("AssignTask").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val taskList = mutableListOf<Task>()
                val currentTime = System.currentTimeMillis()
                var latestOverdue: Task? = null

                for (taskSnapshot in snapshot.children) {
                    val task = taskSnapshot.getValue(Task::class.java) ?: continue
                    
                    val isDeleted = taskSnapshot.child("isDeletedByEmployee").getValue(Boolean::class.java) ?: false ||
                                   taskSnapshot.child("isdeletedbyemployee").getValue(Boolean::class.java) ?: false ||
                                   taskSnapshot.child("deletedbyemployee").getValue(Boolean::class.java) ?: false
                    
                    // Filter by Email (AssignedTo list)
                    if (task.assignedTo.contains(email) && !isDeleted) {
                        taskList.add(task)
                        
                        if (task.submissionStatus != "SUBMITTED" && task.status != "APPROVED") {
                            val deadlineMillis = parseDeadline(task.deadline, task.deadlineTime)
                            if (deadlineMillis != null && deadlineMillis < currentTime) {
                                latestOverdue = task
                            }
                        }
                    }
                }
                _tasks.value = taskList.sortedByDescending { it.createdAt }
                _overdueTaskToNotify.value = latestOverdue
                _isLoading.value = false
            }

            override fun onCancelled(error: DatabaseError) {
                _isLoading.value = false
            }
        })
    }

    private fun fetchNotificationsForEmployee(email: String) {
        employeeNotificationsDatabase.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val notifList = mutableListOf<AppNotification>()
                for (notifSnapshot in snapshot.children) {
                    val notif = notifSnapshot.getValue(AppNotification::class.java)
                    if (notif != null && (notif.targetEmployeeEmail == email || notif.targetEmployeeName == _employeeName.value)) {
                        notifList.add(notif)
                    }
                }
                _notifications.value = notifList.sortedByDescending { it.timestamp }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun parseDeadline(date: String, time: String): Long? {
        return try {
            val format = SimpleDateFormat("dd MMM yyyy hh:mm a", Locale.getDefault())
            format.parse("$date $time")?.time
        } catch (e: Exception) {
            null
        }
    }

    fun dismissOverdueNotification() {
        _overdueTaskToNotify.value = null
    }

    fun submitWork(taskId: String) {
        val task = _tasks.value.find { it.id == taskId } ?: return
        
        database.child("AssignTask").child(taskId).child("submissionStatus").setValue("SUBMITTED").addOnSuccessListener {
            val notification = AppNotification(
                id = UUID.randomUUID().toString(),
                title = "Project Submitted",
                message = "${_employeeName.value} submitted \"${task.title}\"",
                timestamp = System.currentTimeMillis(),
                type = "TASK_SUBMITTED"
            )
            managerNotificationsDatabase.push().setValue(notification)
        }

        val submissionId = database.child("TaskSubmissions").push().key ?: taskId
        val currentDate = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        val currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        val submissionData = SubmittedTask(
            taskId = taskId,
            taskTitle = task.title,
            employeeName = _employeeName.value,
            submissionDate = currentDate,
            submissionTime = currentTime
        )

        database.child("TaskSubmissions").child(submissionId).setValue(submissionData)
    }

    fun clearNotifications() {
        val email = _employeeEmail.value
        employeeNotificationsDatabase.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (notifSnapshot in snapshot.children) {
                    val targetEmail = notifSnapshot.child("targetEmployeeEmail").getValue(String::class.java)
                    val targetName = notifSnapshot.child("targetEmployeeName").getValue(String::class.java)
                    if (targetEmail == email || targetName == _employeeName.value) {
                        notifSnapshot.ref.removeValue()
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun deleteTask(taskId: String) {
        val updates = mapOf(
            "isDeletedByEmployee" to true
        )
        database.child("AssignTask").child(taskId).updateChildren(updates)
    }

    fun logout(onLogout: () -> Unit) {
        auth.signOut()
        _tasks.value = emptyList()
        _notifications.value = emptyList()
        _employeeName.value = ""
        _employeeEmail.value = ""
        onLogout()
    }
}
