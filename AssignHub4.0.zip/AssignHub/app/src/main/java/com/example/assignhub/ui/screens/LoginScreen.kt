package com.example.assignhub.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.assignhub.R
import com.example.assignhub.viewmodels.AuthMode
import com.example.assignhub.viewmodels.LoginScreenViewModel

@Composable
fun LoginScreen(
    onBack: () -> Unit,
    onNavigateToManager: () -> Unit,
    onNavigateToEmployee: () -> Unit,
    viewModel: LoginScreenViewModel = viewModel()
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Modern UI Theme Colors (Updated for Logo Theme)
    val bgGradientStart = Color(0xFFF8FAFC)
    val bgGradientEnd = Color(0xFFF1F5F9)
    val accentColor = Color(0xFF004A8D) // Logo Blue
    val orangeAccent = Color(0xFFBF360C) // Updated to deep Burnt Orange
    val onSurface = Color(0xFF0F172A)
    val surfaceColor = Color.White

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(bgGradientStart, bgGradientEnd)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(60.dp))

            // Brand Identity (Updated to use Image Logo)
            Surface(
                modifier = Modifier
                    .size(100.dp)
                    .shadow(15.dp, RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                color = Color.White
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(12.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.logo),
                        contentDescription = "AssignHub Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(text = "AssignHub", fontSize = 32.sp, fontWeight = FontWeight.Black, color = accentColor, letterSpacing = (-1).sp)
            Text(text = "Simplify Work. Empower Teams.", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = onSurface.copy(alpha = 0.5f), letterSpacing = 0.5.sp)

            Spacer(modifier = Modifier.height(40.dp))

            // Mode Selector
            if (viewModel.authMode != AuthMode.RESET) {
                Surface(
                    modifier = Modifier.fillMaxWidth().height(56.dp).shadow(2.dp, RoundedCornerShape(28.dp)),
                    shape = RoundedCornerShape(28.dp),
                    color = surfaceColor
                ) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        Box(
                            modifier = Modifier.weight(1f).fillMaxHeight().padding(4.dp).clip(RoundedCornerShape(24.dp))
                                .background(if (viewModel.authMode == AuthMode.LOGIN) accentColor else Color.Transparent)
                                .clickable { viewModel.authMode = AuthMode.LOGIN },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("SIGN IN", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = if (viewModel.authMode == AuthMode.LOGIN) Color.White else onSurface.copy(alpha = 0.6f), letterSpacing = 1.sp)
                        }
                        Box(
                            modifier = Modifier.weight(1f).fillMaxHeight().padding(4.dp).clip(RoundedCornerShape(24.dp))
                                .background(if (viewModel.authMode == AuthMode.REGISTER) accentColor else Color.Transparent)
                                .clickable { viewModel.authMode = AuthMode.REGISTER },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("REGISTER", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = if (viewModel.authMode == AuthMode.REGISTER) Color.White else onSurface.copy(alpha = 0.6f), letterSpacing = 1.sp)
                        }
                    }
                }
            } else {
                Text(
                    text = "RECOVER ACCOUNT",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    color = orangeAccent,
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            // Form Content
            AnimatedContent(
                targetState = viewModel.authMode,
                transitionSpec = { fadeIn(animationSpec = tween(400)) togetherWith fadeOut(animationSpec = tween(400)) using SizeTransform(clip = false) },
                label = ""
            ) { targetMode ->
                Column(modifier = Modifier.fillMaxWidth()) {
                    NexusTextField(
                        value = viewModel.email,
                        onValueChange = { viewModel.email = it },
                        label = "Professional Email",
                        icon = Icons.Default.Email,
                        accentColor = accentColor,
                        onSurface = onSurface
                    )

                    if (targetMode != AuthMode.RESET) {
                        Spacer(modifier = Modifier.height(16.dp))
                        NexusTextField(
                            value = viewModel.password,
                            onValueChange = { viewModel.password = it },
                            label = "Security Password",
                            icon = Icons.Default.Lock,
                            accentColor = accentColor,
                            onSurface = onSurface,
                            isPassword = true
                        )
                    }

                    if (targetMode == AuthMode.REGISTER) {
                        Spacer(modifier = Modifier.height(16.dp))
                        val mismatch = !viewModel.isPasswordMatch && viewModel.confirmPassword.isNotEmpty()
                        NexusTextField(
                            value = viewModel.confirmPassword,
                            onValueChange = { viewModel.confirmPassword = it },
                            label = "Confirm Password",
                            icon = Icons.Default.Lock,
                            accentColor = accentColor,
                            onSurface = onSurface,
                            isPassword = true,
                            isError = mismatch
                        )
                    }

                    if (targetMode == AuthMode.LOGIN) {
                        Text(
                            text = "Forgot password?",
                            color = orangeAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.End).padding(top = 10.dp).clickable { viewModel.authMode = AuthMode.RESET }
                        )
                    }

                    if (targetMode == AuthMode.RESET) {
                        Text(
                            text = "Back to Sign In",
                            color = onSurface.copy(alpha = 0.5f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp).clickable { viewModel.authMode = AuthMode.LOGIN }
                        )
                    }

                    Spacer(modifier = Modifier.height(25.dp))

                    Button(
                        onClick = {
                            if (viewModel.canSubmit) {
                                viewModel.handleAuth(
                                    onNavigateToManager = onNavigateToManager,
                                    onNavigateToEmployee = onNavigateToEmployee,
                                    onShowToast = { msg ->
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    }
                                )
                            }
                        },
                        enabled = !viewModel.isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .shadow(12.dp, RoundedCornerShape(18.dp)),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = accentColor,
                            contentColor = Color.White,
                            disabledContainerColor = accentColor.copy(alpha = 0.6f)
                        )
                    ) {
                        if (viewModel.isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 3.dp)
                        } else {
                            val buttonText = when (targetMode) {
                                AuthMode.LOGIN -> "SIGN IN"
                                AuthMode.REGISTER -> "CREATE ACCOUNT"
                                AuthMode.RESET -> "SEND RESET LINK"
                            }
                            Text(
                                text = buttonText,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(100.dp)) // Extra space for scrolling when keyboard is up
        }

        // Back Component
        Box(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    if (viewModel.authMode == AuthMode.RESET) viewModel.authMode = AuthMode.LOGIN else onBack()
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(imageVector = Icons.AutoMirrored.Filled.Reply, contentDescription = "Back", modifier = Modifier.size(28.dp), tint = onSurface.copy(alpha = 0.3f))
                Text(text = "GO BACK", fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = onSurface.copy(alpha = 0.3f))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexusTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onSurface: Color,
    isPassword: Boolean = false,
    isError: Boolean = false
) {
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    Column {
        Text(
            text = label.uppercase(),
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            color = if (isError) Color.Red else onSurface.copy(alpha = 0.4f),
            letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            leadingIcon = { Icon(icon, contentDescription = null, tint = if (isError) Color.Red else accentColor, modifier = Modifier.size(20.dp)) },
            trailingIcon = if (isPassword) {
                {
                    val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    val description = if (passwordVisible) "Hide password" else "Show password"

                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = description, tint = onSurface.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
                    }
                }
            } else null,
            visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth()
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            singleLine = true,
            isError = isError,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accentColor,
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                cursorColor = accentColor,
                focusedContainerColor = Color(0xFFE2E8F0),
                unfocusedContainerColor = Color(0xFFE2E8F0),
                errorBorderColor = Color.Red
            )
        )
    }
}
