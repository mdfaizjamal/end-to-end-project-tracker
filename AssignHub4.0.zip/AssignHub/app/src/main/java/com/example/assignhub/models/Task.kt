package com.example.assignhub.models

data class Task(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val assignedTo: List<String> = emptyList(),
    val assignedToNames: List<String> = emptyList(),
    val priority: String = "MEDIUM",
    val deadline: String = "",
    val deadlineTime: String = "",
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val submissionStatus: String = "NOT_SUBMITTED", // SUBMITTED, NOT_SUBMITTED
    val rejectionReason: String = "",
    val isDeletedByManager: Boolean = false,
    val isDeletedByEmployee: Boolean = false,
    val lastSubmissionDate: String = "",
    val lastSubmissionTime: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
