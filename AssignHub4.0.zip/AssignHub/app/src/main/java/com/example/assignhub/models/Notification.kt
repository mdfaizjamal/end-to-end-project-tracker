package com.example.assignhub.models

data class AppNotification(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val type: String = "", // "TASK_ASSIGNED", "TASK_SUBMITTED", "TASK_STATUS_UPDATE"
    val targetEmployeeName: String = "",
    val targetEmployeeEmail: String = "" // Added for robust filtering
)
