package com.example.assignhub.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.assignhub.models.AppNotification
import com.example.assignhub.models.Employee
import com.example.assignhub.models.Task
import com.example.assignhub.utils.getHighlightedText
import com.example.assignhub.viewmodels.ProjectManagerViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProjectManagerScreen(
    onLogout: () -> Unit,
    viewModel: ProjectManagerViewModel = viewModel()
) {
    val context = LocalContext.current
    
    // Updated employees list with emails for robust identification
    val employees = remember {
        listOf(
            Employee("kishansingam4@gmail.com", "KS", "Kishan Singam"),
            Employee("skayan2910@gmail.com", "AS", "Ayan Sheikh"),
            Employee("rohanhtandale11@gmail.com", "RT", "Rohan Tandale"),
            Employee("hardikbaraskar262@gmail.com", "HB", "Hardik Baraskar"),
        )
    }

    val tasks by viewModel.tasks
    val isLoading by viewModel.isLoading
    val managerName by viewModel.managerName
    val notifications by viewModel.notifications
    
    var selectedTaskForDetail by remember { mutableStateOf<Task?>(null) }
    var showNotifications by rememberSaveable { mutableStateOf(false) }
    var showAddTask by rememberSaveable { mutableStateOf(false) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var isSearchVisible by rememberSaveable { mutableStateOf(false) }
    
    var selectedFilter by rememberSaveable { mutableStateOf("ALL") }
    var showFilterMenu by rememberSaveable { mutableStateOf(false) }
    
    var newTaskTitle by rememberSaveable { mutableStateOf("") }
    var newTaskDesc by rememberSaveable { mutableStateOf("") }
    var selectedEmployees by remember { mutableStateOf(setOf<Employee>()) }
    var selectedPriority by rememberSaveable { mutableStateOf("MEDIUM") }
    var deadlineDate by rememberSaveable { mutableStateOf("") }
    var deadlineTime by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = showNotifications || selectedTaskForDetail != null || showAddTask || isSearchVisible) {
        if (showNotifications) {
            showNotifications = false
        } else if (selectedTaskForDetail != null) {
            selectedTaskForDetail = null
        } else if (showAddTask) {
            showAddTask = false
        } else if (isSearchVisible) {
            isSearchVisible = false
            searchQuery = ""
        }
    }

    val adminAccent = Color(0xFFBF360C) 
    val adminBg = Color(0xFFFFF7F2)

    val filteredTasks = tasks.filter { task ->
        val matchesSearch = if (searchQuery.isEmpty()) true else {
            task.title.contains(searchQuery, ignoreCase = true) || 
            task.description.contains(searchQuery, ignoreCase = true)
        }
        val matchesFilter = if (selectedFilter == "ALL") true else task.status == selectedFilter
        matchesSearch && matchesFilter
    }

    if (showNotifications) {
        NotificationsScreen(
            notifications = notifications,
            onClearAll = { viewModel.clearNotifications() },
            onBack = { showNotifications = false }
        )
    } else if (selectedTaskForDetail != null) {
        TaskDetailScreen(
            task = selectedTaskForDetail!!,
            accentColor = adminAccent,
            onBack = { selectedTaskForDetail = null }
        )
    } else {
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showAddTask = !showAddTask },
                    containerColor = adminAccent,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.padding(bottom = 16.dp, start = 16.dp)
                ) {
                    Icon(if (showAddTask) Icons.Default.Close else Icons.Default.Add, contentDescription = "Add Task")
                }
            },
            floatingActionButtonPosition = FabPosition.Start
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(adminBg)
                    .padding(padding)
            ) {
                ManagerHeaderSection(
                    managerName = managerName,
                    accentColor = adminAccent,
                    onLogout = { viewModel.logout(onLogout) },
                    onSearchToggle = { isSearchVisible = !isSearchVisible },
                    onFilterToggle = { showFilterMenu = true },
                    onNotificationsClick = { showNotifications = true },
                    notificationCount = notifications.size
                )

                Box(modifier = Modifier.fillMaxWidth().wrapContentSize(Alignment.TopEnd).padding(end = 24.dp)) {
                    DropdownMenu(
                        expanded = showFilterMenu,
                        onDismissRequest = { showFilterMenu = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        listOf("ALL", "PENDING", "APPROVED", "REJECTED").forEach { filter ->
                            DropdownMenuItem(
                                text = { 
                                    Text(
                                        text = filter, 
                                        fontWeight = if (selectedFilter == filter) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedFilter == filter) adminAccent else Color.Black
                                    ) 
                                },
                                onClick = {
                                    selectedFilter = filter
                                    showFilterMenu = false
                                }
                            )
                        }
                    }
                }

                AnimatedVisibility(
                    visible = isSearchVisible,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        placeholder = { Text("Search tasks...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = adminAccent) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search", tint = Color.Gray)
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = adminAccent,
                            unfocusedBorderColor = Color.LightGray,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Color.Black,
                            unfocusedTextColor = Color.Black
                        ),
                        singleLine = true
                    )
                }

                if (isLoading && tasks.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = adminAccent)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            AnimatedVisibility(
                                visible = showAddTask,
                                enter = fadeIn() + expandVertically(),
                                exit = fadeOut() + shrinkVertically()
                            ) {
                                AddTaskCard(
                                    accentColor = adminAccent,
                                    title = newTaskTitle,
                                    onTitleChange = { newTaskTitle = it },
                                    description = newTaskDesc,
                                    onDescChange = { newTaskDesc = it },
                                    deadline = deadlineDate,
                                    onDeadlineChange = { deadlineDate = it },
                                    deadlineTime = deadlineTime,
                                    onDeadlineTimeChange = { deadlineTime = it },
                                    employeesList = employees,
                                    selectedEmployeesSet = selectedEmployees,
                                    onEmployeeToggle = { emp ->
                                        selectedEmployees = if (selectedEmployees.contains(emp)) {
                                            selectedEmployees - emp
                                        } else {
                                            selectedEmployees + emp
                                        }
                                    },
                                    priority = selectedPriority,
                                    onPriorityChange = { selectedPriority = it },
                                    onAssign = {
                                        val combinedDateTime = if (deadlineDate.isNotEmpty() && deadlineTime.isNotEmpty()) {
                                            try {
                                                val format = SimpleDateFormat("dd MMM yyyy hh:mm a", Locale.getDefault())
                                                format.parse("$deadlineDate $deadlineTime")?.time ?: 0L
                                            } catch (e: Exception) { 0L }
                                        } else 0L

                                        if (newTaskTitle.trim().length < 2) {
                                            Toast.makeText(context, "Title must be at least 2 characters", Toast.LENGTH_SHORT).show()
                                        } else if (!newTaskTitle.any { it.isLetter() }) {
                                            Toast.makeText(context, "Title must contain at least one letter", Toast.LENGTH_SHORT).show()
                                        } else if (deadlineDate.isEmpty() || deadlineTime.isEmpty()) {
                                            Toast.makeText(context, "Please select both deadline date and time", Toast.LENGTH_SHORT).show()
                                        } else if (combinedDateTime < System.currentTimeMillis()) {
                                            Toast.makeText(context, "Deadline cannot be in the past!", Toast.LENGTH_SHORT).show()
                                        } else if (selectedEmployees.isEmpty()) {
                                            Toast.makeText(context, "Please assign to at least one employee", Toast.LENGTH_SHORT).show()
                                        } else {
                                            viewModel.addTask(
                                                title = newTaskTitle,
                                                description = newTaskDesc,
                                                assignedTo = selectedEmployees.map { it.email }, // Use Email as ID
                                                assignedToNames = selectedEmployees.map { it.name },
                                                priority = selectedPriority,
                                                deadline = deadlineDate,
                                                deadlineTime = deadlineTime
                                            )
                                            showAddTask = false
                                            newTaskTitle = ""
                                            newTaskDesc = ""
                                            selectedEmployees = setOf()
                                            deadlineDate = ""
                                            deadlineTime = ""
                                        }
                                    }
                                )
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (searchQuery.isEmpty()) "PROJECT TASKS" else "SEARCH RESULTS",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray,
                                    letterSpacing = 1.sp
                                )
                                if (selectedFilter != "ALL") {
                                    Surface(
                                        modifier = Modifier.clickable { selectedFilter = "ALL" },
                                        shape = RoundedCornerShape(16.dp),
                                        color = adminAccent.copy(alpha = 0.1f),
                                        border = BorderStroke(1.dp, adminAccent.copy(alpha = 0.5f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(selectedFilter, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = adminAccent)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp), tint = adminAccent)
                                        }
                                    }
                                }
                            }
                        }

                        items(filteredTasks) { task ->
                            TaskCard(
                                accentColor = adminAccent,
                                task = task,
                                searchQuery = searchQuery,
                                onClick = { selectedTaskForDetail = task },
                                onApprove = {
                                    viewModel.updateTaskStatus(task.id, "APPROVED")
                                },
                                onReject = { reason ->
                                    viewModel.updateTaskStatus(task.id, "REJECTED", reason)
                                },
                                onDelete = {
                                    viewModel.deleteTask(task.id)
                                }
                            )
                        }
                        
                        if (filteredTasks.isEmpty() && !isLoading) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                                    Text("No tasks found matching your criteria.", color = Color.Gray)
                                }
                            }
                        }
                        
                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationsScreen(
    notifications: List<AppNotification>,
    onClearAll: () -> Unit,
    onBack: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Notifications",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                if (notifications.isNotEmpty()) {
                    TextButton(onClick = onClearAll) {
                        Text("Clear All", color = Color.Red, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (notifications.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.NotificationsNone, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No notifications yet", color = Color.Gray)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(notifications) { notification ->
                        NotificationCard(notification)
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
fun NotificationCard(notification: AppNotification) {
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    val dateString = sdf.format(Date(notification.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = notification.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black
                )
                Text(
                    text = dateString,
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = notification.message,
                fontSize = 14.sp,
                color = Color.DarkGray
            )
        }
    }
}

@Composable
fun TaskDetailScreen(task: Task, accentColor: Color, onBack: () -> Unit) {
    val bgColor = Color(0xFFFFF7F2)

    Surface(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        color = bgColor
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .size(40.dp)
                        .clickable { onBack() },
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 2.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack, 
                            contentDescription = "Back", 
                            modifier = Modifier.size(20.dp),
                            tint = Color.Black
                        )
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("Task Overview", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .shadow(10.dp, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = task.title,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1E293B)
                        )
                        Badge(
                            containerColor = if (task.priority == "HIGH") Color(0xFFFFEBEE) else Color(0xFFFFF3E0),
                            contentColor = if (task.priority == "HIGH") Color(0xFFD32F2F) else Color(0xFFEF6C00)
                        ) {
                            Text(task.priority, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "MANAGER STATUS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text(
                                text = task.status,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = when(task.status) {
                                    "APPROVED" -> Color(0xFF2E7D32)
                                    "REJECTED" -> Color(0xFFC62828)
                                    else -> accentColor
                                }
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "EMP SUBMISSION",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text(
                                text = if (task.submissionStatus == "SUBMITTED") "SUBMITTED" else "NOT SUBMITTED",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (task.submissionStatus == "SUBMITTED") accentColor else Color.Gray
                            )
                        }
                    }

                    if (task.status == "REJECTED") {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "REJECTION REASON",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Red
                        )
                        Text(task.rejectionReason, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "DESCRIPTION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Text(
                        text = task.description,
                        fontSize = 15.sp,
                        color = Color.Black,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "DEADLINE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp), tint = accentColor)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${task.deadline} ${task.deadlineTime}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TEAM",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                task.assignedToNames.forEach { name ->
                                    Text(name, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ManagerHeaderSection(
    managerName: String, 
    accentColor: Color, 
    onLogout: () -> Unit, 
    onSearchToggle: () -> Unit, 
    onFilterToggle: () -> Unit,
    onNotificationsClick: () -> Unit,
    notificationCount: Int = 0
) {
    val calendar = Calendar.getInstance()
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val greeting = when (hour) {
        in 0..11 -> "Good Morning"
        in 12..16 -> "Good Afternoon"
        else -> "Good Evening"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("Hi, $managerName", fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = (-0.5).sp)
            Text("$greeting, Ready to manage?", color = accentColor, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onSearchToggle) {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray)
            }
            IconButton(onClick = onFilterToggle) {
                Icon(Icons.Default.FilterList, contentDescription = "Filter", tint = Color.Gray)
            }
            IconButton(onClick = onNotificationsClick) {
                if (notificationCount > 0) {
                    BadgedBox(badge = { Badge { Text(notificationCount.toString()) } }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color(0xFFD4AF37))
                    }
                } else {
                    Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = onLogout) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout", tint = Color.Red)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskCard(
    accentColor: Color,
    title: String,
    onTitleChange: (String) -> Unit,
    description: String,
    onDescChange: (String) -> Unit,
    deadline: String,
    onDeadlineChange: (String) -> Unit,
    deadlineTime: String,
    onDeadlineTimeChange: (String) -> Unit,
    employeesList: List<Employee>,
    selectedEmployeesSet: Set<Employee>,
    onEmployeeToggle: (Employee) -> Unit,
    priority: String,
    onPriorityChange: (String) -> Unit,
    onAssign: () -> Unit
) {
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    var showEmployeeDropdown by remember { mutableStateOf(false) }
    
    val datePickerState = rememberDatePickerState(
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                return utcTimeMillis >= calendar.timeInMillis
            }
        }
    )
    val timePickerState = rememberTimePickerState()

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let {
                        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                        onDeadlineChange(sdf.format(Date(it)))
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (showTimePicker) {
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val formattedHour = if (timePickerState.hour % 12 == 0) 12 else timePickerState.hour % 12
                    val minute = if (timePickerState.minute < 10) "0${timePickerState.minute}" else "${timePickerState.minute}"
                    val amPm = if (timePickerState.hour < 12) "AM" else "PM"
                    onDeadlineTimeChange("$formattedHour:$minute $amPm")
                    showTimePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) { Text("Cancel") }
            },
            text = {
                TimePicker(state = timePickerState)
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("ASSIGN NEW TASK", color = accentColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedTextField(
                value = title,
                onValueChange = onTitleChange,
                placeholder = { Text("Task title") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFF1F5F9),
                    unfocusedContainerColor = Color(0xFFF1F5F9),
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = description,
                onValueChange = onDescChange,
                placeholder = { Text("Description") },
                modifier = Modifier.fillMaxWidth().height(80.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFF1F5F9),
                    unfocusedContainerColor = Color(0xFFF1F5F9),
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f).clickable { showDatePicker = true }) {
                    OutlinedTextField(
                        value = deadline,
                        onValueChange = {},
                        enabled = false,
                        placeholder = { Text("Select Date") },
                        leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = accentColor) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledContainerColor = Color(0xFFF1F5F9),
                            disabledBorderColor = Color.Transparent,
                            disabledTextColor = Color.Black,
                            disabledPlaceholderColor = Color.Gray
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
                
                Box(modifier = Modifier.weight(1f).clickable { showTimePicker = true }) {
                    OutlinedTextField(
                        value = deadlineTime,
                        onValueChange = {},
                        enabled = false,
                        placeholder = { Text("Select Time") },
                        leadingIcon = { Icon(Icons.Default.AccessTime, contentDescription = null, tint = accentColor) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledContainerColor = Color(0xFFF1F5F9),
                            disabledBorderColor = Color.Transparent,
                            disabledTextColor = Color.Black,
                            disabledPlaceholderColor = Color.Gray
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("ASSIGN TO TEAM", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))
            
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = if (selectedEmployeesSet.isEmpty()) "Select team members" else selectedEmployeesSet.joinToString(", ") { it.initials },
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        Icon(
                            if (showEmployeeDropdown) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = accentColor
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFFF1F5F9),
                        unfocusedContainerColor = Color(0xFFF1F5F9),
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
                Box(modifier = Modifier.matchParentSize().clickable { showEmployeeDropdown = !showEmployeeDropdown })

                DropdownMenu(
                    expanded = showEmployeeDropdown,
                    onDismissRequest = { showEmployeeDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.8f).background(Color.White)
                ) {
                    employeesList.forEach { emp ->
                        val isSelected = selectedEmployeesSet.contains(emp)
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = null,
                                        colors = CheckboxDefaults.colors(checkedColor = accentColor)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(emp.name, fontSize = 14.sp)
                                }
                            },
                            onClick = { onEmployeeToggle(emp) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("LOW", "MEDIUM", "HIGH").forEach { level ->
                    val isSelected = priority == level
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clickable { onPriorityChange(level) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) accentColor else Color(0xFFF1F5F9)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                level,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Color.Gray
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onAssign,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor)
            ) {
                Text("ASSIGN TASK", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TaskCard(
    accentColor: Color,
    task: Task,
    searchQuery: String,
    onClick: () -> Unit,
    onApprove: () -> Unit,
    onReject: (String) -> Unit,
    onDelete: () -> Unit
) {
    var showRejectInput by remember { mutableStateOf(false) }
    var showConfirmApprove by remember { mutableStateOf(false) }
    var rejectionText by remember { mutableStateOf("") }
    
    val isSubmitted = task.submissionStatus == "SUBMITTED"
    val isRejected = task.status == "REJECTED"

    if (showConfirmApprove) {
        AlertDialog(
            onDismissRequest = { showConfirmApprove = false },
            title = { Text(if (isRejected) "Confirm Approve Again" else "Confirm Approval") },
            text = { Text("Are you sure you want to approve this task?") },
            confirmButton = {
                Button(onClick = {
                    onApprove()
                    showConfirmApprove = false
                }) { Text("Yes") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmApprove = false }) { Text("No") }
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = accentColor.copy(alpha = 0.5f),
                spotColor = accentColor
            )
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(6.dp)
                    .background(
                        when (task.priority) {
                            "HIGH" -> Color(0xFFE53935)
                            "MEDIUM" -> Color(0xFFFB8C00)
                            else -> Color(0xFF43A047)
                        }
                    )
                    .align(Alignment.CenterStart)
            )

            Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = getHighlightedText(task.title, searchQuery, Color(0xFFBF360C)),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = Color(0xFF1E293B),
                        modifier = Modifier.weight(1f)
                    )
                    
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (task.status == "APPROVED" || task.status == "REJECTED") {
                            IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when (task.priority) {
                                "HIGH" -> Color(0xFFFFEBEE)
                                "MEDIUM" -> Color(0xFFFFF3E0)
                                else -> Color(0xFFE8F5E9)
                            },
                            border = BorderStroke(1.dp, when (task.priority) {
                                "HIGH" -> Color(0xFFEF9A9A)
                                "MEDIUM" -> Color(0xFFFFCC80)
                                else -> Color(0xFFA5D6A7)
                            })
                        ) {
                            Text(
                                task.priority, 
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = when (task.priority) {
                                    "HIGH" -> Color(0xFFC62828)
                                    "MEDIUM" -> Color(0xFFEF6C00)
                                    else -> Color(0xFF2E7D32)
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                
                Text(
                    text = getHighlightedText(task.description, searchQuery, Color(0xFFBF360C)),
                    color = Color.Black, 
                    fontSize = 14.sp, 
                    maxLines = 2,
                    lineHeight = 18.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Row(horizontalArrangement = Arrangement.spacedBy((-10).dp)) {
                            // Extract initials from names if assignedTo (emails) is used
                            val initials = task.assignedToNames.map { it.split(" ").mapNotNull { part -> part.firstOrNull() }.joinToString("").uppercase() }
                            initials.take(3).forEach { initial ->
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(
                                            Brush.linearGradient(listOf(accentColor.copy(alpha = 0.1f), Color(0xFFF1F5F9))), 
                                            CircleShape
                                        )
                                        .border(2.dp, Color.White, CircleShape)
                                        .shadow(1.dp, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(initial, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF334155))
                                }
                            }
                            if (task.assignedToNames.size > 3) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFFE2E8F0), CircleShape)
                                        .border(2.dp, Color.White, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("+${task.assignedToNames.size - 3}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(task.deadline, fontSize = 11.sp, color = Color(0xFF475569), fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Surface(
                            shape = CircleShape,
                            color = if (isSubmitted) accentColor.copy(alpha = 0.1f) else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (isSubmitted) accentColor.copy(alpha = 0.3f) else Color.Transparent)
                        ) {
                            Text(
                                text = if (isSubmitted) "SUBMITTED" else "PENDING",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSubmitted) accentColor else Color.Gray
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = when(task.status) {
                                "PENDING" -> Color(0xFFFFF3E0)
                                "APPROVED" -> Color(0xFFE8F5E9)
                                else -> Color(0xFFFFEBEE)
                            }
                        ) {
                            Text(
                                text = task.status, 
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = when(task.status) {
                                    "PENDING" -> Color(0xFFEF6C00)
                                    "APPROVED" -> Color(0xFF2E7D32)
                                    else -> Color(0xFFC62828)
                                }
                            )
                        }
                    }
                }

                if (task.status == "PENDING" || task.status == "REJECTED") {
                    Spacer(modifier = Modifier.height(16.dp))
                    if (!showRejectInput) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { if (isSubmitted) showConfirmApprove = true },
                                enabled = isSubmitted,
                                modifier = Modifier.weight(1f).height(40.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF2E7D32),
                                    disabledContainerColor = Color(0xFF2E7D32).copy(alpha = 0.3f)
                                ),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isRejected) "Approve Again" else "Approve", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { if (isSubmitted) showRejectInput = true },
                                enabled = isSubmitted,
                                modifier = Modifier.weight(1f).height(40.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (isSubmitted) Color(0xFFC62828) else Color(0xFFC62828).copy(alpha = 0.3f)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFFC62828),
                                    disabledContentColor = Color(0xFFC62828).copy(alpha = 0.3f)
                                )
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isRejected) "Reject Again" else "Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Column {
                            OutlinedTextField(
                                value = rejectionText,
                                onValueChange = { rejectionText = it },
                                placeholder = { Text("Reason for rejection...") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.Black,
                                    unfocusedTextColor = Color.Black,
                                    focusedBorderColor = Color.Red,
                                    unfocusedBorderColor = Color.LightGray
                                )
                            )
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { 
                                    showRejectInput = false 
                                    rejectionText = ""
                                }) { Text("Cancel") }
                                TextButton(onClick = { 
                                    onReject(rejectionText) 
                                    showRejectInput = false
                                    rejectionText = ""
                                }) { 
                                    Text("Submit Rejection", color = Color.Red, fontWeight = FontWeight.Bold) 
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
