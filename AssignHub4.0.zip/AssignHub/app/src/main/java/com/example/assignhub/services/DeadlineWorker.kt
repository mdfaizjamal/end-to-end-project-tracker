package com.example.assignhub.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.assignhub.MainActivity
import com.example.assignhub.R
import com.example.assignhub.models.AppNotification
import com.example.assignhub.models.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class DeadlineWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    private val database = FirebaseDatabase.getInstance().getReference("AssignTask")
    private val usersDatabase = FirebaseDatabase.getInstance().getReference("users")
    private val managerNotificationsDatabase = FirebaseDatabase.getInstance().getReference("manager_notifications")
    private val employeeNotificationsDatabase = FirebaseDatabase.getInstance().getReference("employee_notifications")

    override suspend fun doWork(): Result {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return Result.success()

        try {
            val snapshot = database.get().await()
            val userSnapshot = usersDatabase.child(userId).get().await()
            val userName = userSnapshot.child("name").getValue(String::class.java) ?: "Employee"
            val userRole = userSnapshot.child("role").getValue(String::class.java) ?: "employee"

            val pref = applicationContext.getSharedPreferences("DeadlinePrefs", Context.MODE_PRIVATE)

            for (taskSnapshot in snapshot.children) {
                val task = taskSnapshot.getValue(Task::class.java) ?: continue
                
                // Only process pending tasks
                if (task.status == "APPROVED" || task.submissionStatus == "SUBMITTED") continue

                val deadlineMillis = parseDeadline(task.deadline, task.deadlineTime) ?: continue
                val currentTime = System.currentTimeMillis()
                val diffMillis = deadlineMillis - currentTime
                val diffMinutes = TimeUnit.MILLISECONDS.toMinutes(diffMillis)
                val diffHours = TimeUnit.MILLISECONDS.toHours(diffMillis)

                val lastNotifiedKey = "notified_${task.id}_"

                // Employee Notifications logic refined for better accuracy
                if (userRole == "employee" && task.assignedToNames.contains(userName)) {
                    when {
                        // 6 Hour Alert
                        diffHours in 5..6 && !pref.getBoolean("${lastNotifiedKey}6h", false) -> {
                            val msg = "$userName, your task \"${task.title}\" deadline is about to complete in 6 hours."
                            sendLocalNotification("Deadline Approaching (6h)", msg)
                            pushNotificationToDb(employeeNotificationsDatabase, "Deadline Alert", msg, "DEADLINE_6H", userName)
                            pref.edit().putBoolean("${lastNotifiedKey}6h", true).apply()
                        }
                        // 3 Hour Alert
                        diffHours in 2..3 && !pref.getBoolean("${lastNotifiedKey}3h", false) -> {
                            val msg = "$userName, your task \"${task.title}\" deadline is about to complete in 3 hours."
                            sendLocalNotification("Deadline Approaching (3h)", msg)
                            pushNotificationToDb(employeeNotificationsDatabase, "Deadline Alert", msg, "DEADLINE_3H", userName)
                            pref.edit().putBoolean("${lastNotifiedKey}3h", true).apply()
                        }
                        // 1 Hour Alert
                        diffMinutes in 0..65 && !pref.getBoolean("${lastNotifiedKey}1h", false) -> {
                            val msg = "$userName, your task \"${task.title}\" deadline is about to complete in 1 hour."
                            sendLocalNotification("Final Hour Alert!", msg)
                            pushNotificationToDb(employeeNotificationsDatabase, "Deadline Alert", msg, "DEADLINE_1H", userName)
                            pref.edit().putBoolean("${lastNotifiedKey}1h", true).apply()
                        }
                        // Deadline Over
                        diffMillis <= 0 && !pref.getBoolean("${lastNotifiedKey}over", false) -> {
                            val msg = "Your project \"${task.title}\" deadline is over. You are not able to complete the task. Communicate with your manager."
                            sendLocalNotification("Deadline Over", msg)
                            pushNotificationToDb(employeeNotificationsDatabase, "Deadline Over", msg, "DEADLINE_OVER", userName)
                            
                            val managerMsg = "Employee ${task.assignedToNames.joinToString()} not submitted task \"${task.title}\". Deadline was ${task.deadline} ${task.deadlineTime}."
                            pushNotificationToDb(managerNotificationsDatabase, "Deadline Missed", managerMsg, "MANAGER_DEADLINE_OVER", "")
                            
                            pref.edit().putBoolean("${lastNotifiedKey}over", true).apply()
                        }
                    }
                }
                
                // Manager check
                if (userRole == "manager") {
                     if (diffMillis <= 0 && !pref.getBoolean("${lastNotifiedKey}manager_alert", false)) {
                         val managerMsg = "Employee ${task.assignedToNames.joinToString()} not submitted task \"${task.title}\". Deadline was ${task.deadline} ${task.deadlineTime}."
                         sendLocalNotification("Deadline Missed", managerMsg)
                         pref.edit().putBoolean("${lastNotifiedKey}manager_alert", true).apply()
                     }
                }
            }
        } catch (e: Exception) {
            return Result.retry()
        }

        return Result.success()
    }

    private fun pushNotificationToDb(ref: com.google.firebase.database.DatabaseReference, title: String, message: String, type: String, targetEmployeeName: String) {
        val id = UUID.randomUUID().toString()
        val notification = AppNotification(
            id = id, 
            title = title, 
            message = message, 
            timestamp = System.currentTimeMillis(), 
            type = type,
            targetEmployeeName = targetEmployeeName
        )
        ref.push().setValue(notification)
    }

    private fun parseDeadline(date: String, time: String): Long? {
        return try {
            val format = SimpleDateFormat("dd MMM yyyy hh:mm a", Locale.getDefault())
            format.parse("$date $time")?.time
        } catch (e: Exception) {
            null
        }
    }

    private fun sendLocalNotification(title: String, messageBody: String) {
        val channelId = "deadline_notifications"
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Deadline Alerts", NotificationManager.IMPORTANCE_HIGH)
            channel.enableVibration(true)
            channel.lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(applicationContext, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        val pendingIntent = PendingIntent.getActivity(applicationContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.logo) // Use app logo
            .setContentTitle(title)
            .setContentText(messageBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText(messageBody))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
